// import React from 'react'
// import ChildComponent2 from './components/ChildComponent2'

// const App = () => {
//   return (
//     <div>
//       <ChildComponent2/>
//     </div>
//   )
// }

// export default App

import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Form from './Form';
import ThankYou from './ThankYou';

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Form/>} />
        <Route path="/thankyou/:name" element={<ThankYou/>} />
      </Routes>
    </BrowserRouter>
  )
}

export default App

//next session => CRUD Create, Read, Update, Delete, 
//map, reduce, filter, split, splice, slice, router, useParams,
//useNavigation, useEffect, useState, useContext, html,css, 
//tailwind css 

//form cretae, read, update, delete.
//add, update, delete, view// products crud

//url structure => ip address (domain name) + path + params

//useParams, to acess data from the url
//useNavigation. just to redirect the pages inthe spa


//Thankyou page. navigation
//form creation => when submitting the form, redirect to thank you page ()