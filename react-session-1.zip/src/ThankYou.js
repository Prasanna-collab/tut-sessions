import React from 'react';
import { useParams } from 'react-router-dom';

const ThankYou = () => {
    const params = useParams();
    const {name}= params;
  return (
    <div>Your Form has been submitted Miss {name}</div>
  )
}

export default ThankYou