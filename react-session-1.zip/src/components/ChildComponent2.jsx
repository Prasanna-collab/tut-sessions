import React, { useState, useEffect } from 'react'

const ChildComponent2 = () => {
    const [totalSeconds, setTotalSeconds] = useState(0);

    useEffect(() => {
        const intervalId = setInterval(() => {
            setTotalSeconds(prev => prev + 1)
        }, 1000);
        return () => clearInterval(intervalId)
    }, [])

    const handelReset = ()=> {
            setTotalSeconds(0)
    }

    const getFunction = () => {
        const hours = Math.floor(totalSeconds / 3600); //7200/3600 => 0,1,2,3=>24
        const minutes = Math.floor((totalSeconds % 3600) / 60); // 1.25 1 min
        const seconds = totalSeconds % 60;
        return `${hours}:${minutes}:${seconds}` 
    }
    return (
        <div>{getFunction()}
        
        {/* start button (watch sud start), stop button (watch stop), reset button(watch sud reset, watch sud stop) */}

        </div>
    )
}

export default ChildComponent2;


// 