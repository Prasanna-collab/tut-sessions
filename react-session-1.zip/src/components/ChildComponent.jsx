import React, { useState, useEffect } from 'react'

const ChildComponent = () => {
  const [state, setState] = useState(0)
  const [show, setShow] = useState(true)

  useEffect(() => {
    console.log('useEffect rendered')
    //   setInterval(() => {

    if (show) setState(prev => prev + 5)
    else return
    //   }, 1000)
  }, [show])

  //voice breaking ka
  // !
  //state value updates evenly after 1 second gap.

  // setInterval (()=> {}, 2000)
  //1. with empty dependency
  //2. without dependecy
  //3. unneccessary dependency.

  console.log('compoent rendered') //

  const handleAdd = payload => {
    //show must be true

    // if (show) setState(prev => prev + payload)
    // else return;

    const timerId = setTimeout(() => {
      console.log('SetTimeout demo')
    }, 5000)
    console.log(timerId)



    //stages of react
    // 1. mounting state => DOM => we insert something in DOM 0 componetDidMount({
    // state =0
    // }),
    //2. updating state=> when we update something on DOM 0 > 1 componentWillUpdate {setState(prev=> prev+1)}
    //3. unmounting state => when we remove something from DOM 0 removed 1 will be placed. componentWillUnmount 0 => 1 

    return ()=>clearTimeout(timerId) 
    //why clean up function are used in useEffect?
    //clean up function will be called when component is unmounted.
    //what is clean up function? it doesn't clear cache at all. instead it clears the state at the time of unmounting.
    
    //Clue: Basically clean up used when we integrated web api in you project.
  }

  return (
    <div>
      {show ? state : null}
      <button onClick={() => setShow(prev => !prev)}>show data </button>
      <button onClick={() => handleAdd()}>add number</button>
    </div>
  )
}

export default ChildComponent
