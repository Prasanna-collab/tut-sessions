import React from 'react'

const Demo = () => {


  //   const val2 = 'Parent will access this?'

  return (
    <div >
        Handle Change button

      {/* subdemo component  handleChange  prop drilling good feature. not => props driling =>  */}
      {/* advisbale to do.  */}
      {/* callback => callback hell .  promise. =>*/}
    </div>
  )
}

export default Demo
