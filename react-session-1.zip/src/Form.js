import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'

const Form = () => {
    const [student, setStudent] = useState({
        name: "",
        email: "",
        phone: "",
        department: "",
        roll_no: ""
    })

    const navigation = useNavigate();
    const handleSubmit = (e) => {
        e.preventDefault()
        console.log("Data submitted...", student);
        navigation(`/thankyou/${student.name}`)
    }
    return (
        <div style={{ height: "100vh", width: "500px", margin: "auto", display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column" }}>
            <header>
                <h1>Student Community Form</h1>
            </header>
            <section style={{ width: "70%" }}>
                <form style={{ border: "1px solid black", padding: "10px", borderRadius: "10px", }}
                    onSubmit={handleSubmit}
                >
                    <div style={{ display: "flex", flexDirection: "column", gap: "10px", margin: "10px 0px" }}>
                        <label style={{ fontWeight: "700", fontSize: "20px", marginLeft: "10px", }}>Name</label>
                        <input type="text" style={{ borderRadius: "6px", height: "24px" }} value={student.name} onChange={(e) => setStudent({ ...student, name: e.target.value })} />
                    </div>
                    <div style={{ display: "flex", flexDirection: "column", gap: "10px", margin: "10px 0px" }}>
                        <label style={{ fontWeight: "700", fontSize: "20px", marginLeft: "10px", }}>Email</label>
                        <input type="email" style={{ borderRadius: "6px", height: "24px" }} value={student.email} onChange={(e) => setStudent({ ...student, email: e.target.value })} />
                    </div>
                    <div style={{ display: "flex", flexDirection: "column", gap: "10px", margin: "10px 0px" }}>
                        <label style={{ fontWeight: "700", fontSize: "20px", marginLeft: "10px", }}>Phone</label>
                        <input type="text" style={{ borderRadius: "6px", height: "24px" }} value={student.phone} onChange={(e) => setStudent({ ...student, phone: e.target.value })} />
                    </div>
                    <div style={{ display: "flex", flexDirection: "column", gap: "10px", margin: "10px 0px" }}>
                        <label style={{ fontWeight: "700", fontSize: "20px", marginLeft: "10px", }}>Department</label>
                        <input type="text" style={{ borderRadius: "6px", height: "24px" }} value={student.department} onChange={(e) => setStudent({ ...student, department: e.target.value })} />
                    </div>
                    <div style={{ display: "flex", flexDirection: "column", gap: "10px", margin: "10px 0px" }}>
                        <label style={{ fontWeight: "700", fontSize: "20px", marginLeft: "10px", }}>Roll No</label>
                        <input type="text" style={{ borderRadius: "6px", height: "24px" }} value={student.roll_no} onChange={(e) => setStudent({ ...student, roll_no: e.target.value })} />
                    </div>
                    <div>
                        <button type="submit">Submit</button>
                    </div>
                </form>
            </section>
        </div>
    )
}

export default Form